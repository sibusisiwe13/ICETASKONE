package com.example.classactivity

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.os.SystemClock
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val thread: GameThread
    private val bird: Bird
    private val pillars = mutableListOf<Pillars>()
    private val paint = Paint()
    private val background: Bitmap
    private var score = 0
    private var startTime: Long = 0

    init{
        holder.addCallback(this)
        bird = Bird(context)
        pillars.add(Pillars(context,600f, 400))
        pillars.add(Pillars(context, 1600f, 300))
        thread = GameThread(holder, this)
        background = BitmapFactory.decodeResource(resources, R.drawable.flappy)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        thread.setRunning(true)
        startTime = SystemClock.elapsedRealtime()

    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        TODO("Not yet implemented")
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        thread.setRunning(false)

        }

    fun update() {
        bird.update()
        for (pillars in pillars) {
            pillars.update()
            if (Rect.intersects(bird.getRectangle(), pillars.getTopRectangle()) || Rect.intersects(
                    bird.getRectangle(),
                    pillars.getBottomRectangle()
                )
            )
                thread.setRunning(false)
            navigateToHomeScreen()
            return
        }
        for (pillars in pillars) {
            pillars.update()
            if (pillars.x + pillars.height < bird.x && !pillars.passed) {
                pillars.passed = true
                score++
            }
        }
    }



    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if( event?.action == MotionEvent.ACTION_DOWN){
            bird.flap()
        }
        return true
    }
    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        canvas.drawBitmap(background, 0f, 0f, null)
        bird.draw(canvas, paint)
        for (pillar in pillars) {
            pillar.draw(canvas, paint)

        }

        drawScore(canvas)
        drawTimer(canvas)
    }
    private fun drawScore(canvas: Canvas) {
        paint.textSize = 10f
        canvas.drawText("Score: $score", 100f, 100f, paint)
    }
    private fun drawTimer(canvas: Canvas){
        val elapsedSeconds = (SystemClock.elapsedRealtime() - startTime)/ 1000
        paint.textSize = 100f
        canvas.drawText("Time: $elapsedSeconds s", 100f, 200f, paint)
    }
    private fun navigateToHomeScreen() {
        val elapsedSeconds = ((SystemClock.elapsedRealtime() - startTime)/ 1000).toInt()
        Log.d("time", "elapsed seconds: $elapsedSeconds")
        val intent = Intent(context, MainActivity::class.java).apply{
            putExtra("score", score)
            putExtra("time", elapsedSeconds)
        }
        context.startActivity(intent)
        (context as MainActivity).finish()
    }


}