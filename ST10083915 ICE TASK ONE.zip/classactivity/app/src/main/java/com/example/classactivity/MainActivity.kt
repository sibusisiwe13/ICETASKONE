package com.example.classactivity


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView


class MainActivity : AppCompatActivity() {
    private lateinit var Startbtn: Button
    private lateinit var Flappy: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        Startbtn = findViewById(R.id.Startbtn)
        Flappy = findViewById(R.id.Flappy)

        Startbtn.setOnClickListener {
            startGame()
        }
    }

    private fun startGame() {
        val gameView = GameView(this)
        setContentView(gameView)
    }
}